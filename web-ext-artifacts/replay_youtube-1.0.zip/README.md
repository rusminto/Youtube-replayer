# Youtube-replayer
Firefox extension to replay video on youtube

Installation steps:
- download code
- open about:debugging in firefox
- click "This Firefox" > "Load Temporary Add-on"
- select manifest.json inside download directory  

Another setup on incognito:
- open about:addons in firefox
- click "Replay Youtube"
- click "Allow"

References:
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Your_second_WebExtension

